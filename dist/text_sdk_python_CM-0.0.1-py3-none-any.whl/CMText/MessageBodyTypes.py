
#Contains all known MessageBodyTypes
class MessageBodyTypes:
    AUTO = 'AUTO'
    BINARY = 'BINARY'
    TEXT = 'TEXT'